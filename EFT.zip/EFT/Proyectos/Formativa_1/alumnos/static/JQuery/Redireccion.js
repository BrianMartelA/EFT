function goTo(url){
    location.href= url;
}