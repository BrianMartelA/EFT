from rest_framework.serializers import ModelSerializer
from alumnos.models import Productos


class PostSerializer(ModelSerializer):
    class Meta:
        model = Productos
        fields = ['id','nombre', 'description', 'price', 'stock', 'categoria', 'image']