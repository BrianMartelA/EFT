from rest_framework.viewsets import ModelViewSet
from alumnos.models import Productos
from alumnos.api.serializers import PostSerializer

class PostApiViewSet(ModelViewSet):
    serializer_class = PostSerializer
    queryset = Productos.objects.all()
