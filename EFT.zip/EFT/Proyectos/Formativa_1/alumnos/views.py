from django.shortcuts import redirect, render, get_object_or_404
from django.urls import reverse
from .forms import SignUpForm, UserProfileForm, BoletaForm,ProductosForm
from .models import cliente,Registro_cliente, BoletaModel,Articulo, Boleta, detalle_boleta,Productos
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import Group
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from alumnos.compra import Carrito
from django.db.models import Q
from django.core.paginator import Paginator
from django.http import Http404
import requests


# Create your views here.
    
def api_data_view(request):
    response = requests.get('http://127.0.0.1:8000/api/post/') 
    dato = response.json() 
    queryset = request.GET.get("buscar")
    page = request.GET.get('page',1)
    try:
        paginator = Paginator(dato,3)
        dato = paginator.page(page)
    except:
        raise Http404
    if queryset:
        data_filtered = [item for item in dato if str(item['id']) == queryset]
    else:
        data_filtered = dato

    # Configurar paginación para los datos filtrados
    paginator = Paginator(data_filtered, 3)
    try:
        page_obj = paginator.page(page)
    except EmptyPage:
        page_obj = paginator.page(1)
    

    datos={
        'paginator':paginator,
        'dato': page_obj
    }
    return render(request, 'alumnos/api.html',datos)

def index(request):
    context ={}
    return render(request,'alumnos/index.html',context)

def galeria(request):
    data = Productos.objects.all() 
    queryset = request.GET.get("buscar")
    page = request.GET.get('page',1)
    try:
        paginator = Paginator(data,3)
        data = paginator.page(page)
    except:
        raise Http404
    if queryset:
        data =Productos.objects.filter(
            Q(id = queryset)
        ).distinct()
    print(request.GET)
    

    datos={
        'data':data,
        'paginator':paginator
    }
    return render(request, 'alumnos/Galeria.html', datos)
def contacto(request):
    context= {}
    return render(request,'alumnos/contacto.html',context)

def quienes_somos(request):
    context = {}
    return render(request,'alumnos/Quienes_somos.html',context)

def boulder(request):
    context = {}
    return render(request,'alumnos/Boulder.html',context)


def test(request):
    context ={}
    return render(request,'alumnos/test.html',context)




def registro(request):
    data ={
        'form' : SignUpForm()
    }
    if request.method=="POST":
        formulario= SignUpForm(data=request.POST)
        if formulario.is_valid():

            user=formulario.save()
            Registro_cliente.objects.create(user=user)
            group = Group.objects.get(name='cliente')
            user.groups.add(group)

            user=authenticate(username=formulario.cleaned_data["username"], password=formulario.cleaned_data["password1"])
            login(request, user)
            messages.success(request, "Te has registrado correctamente")
            return redirect('index')
        data["form"] = formulario
    return render(request, 'alumnos/registro.html',data)


def tienda(request):
    queryset = request.GET.get("buscar")
    articulos = Articulo.objects.all()
    page = request.GET.get('page',1)
    try:
        paginator = Paginator(articulos,2)
        articulos = paginator.page(page)
    except:
        raise Http404
    if queryset:
        articulos = Articulo.objects.filter(
            Q(codigo = queryset)
        ).distinct()
    print(request.GET)
    

    datos={
        'entity':articulos,
        'paginator':paginator
    }
    return render(request, 'alumnos/tienda.html', datos)


def agregar_producto(request,id):
    carrito_compra= Carrito(request)
    articulo = Articulo.objects.get(codigo=id)
    carrito_compra.agregar(articulo=articulo)
    return redirect('tienda')

def eliminar_producto(request, id):
    carrito_compra= Carrito(request)
    articulo = Articulo.objects.get(codigo=id)
    carrito_compra.eliminar(articulo=articulo)
    return redirect('tienda')

def restar_producto(request, id):
    carrito_compra= Carrito(request)
    articulo = Articulo.objects.get(codigo=id)
    carrito_compra.restar(articulo=articulo)
    return redirect('tienda')

def limpiar_carrito(request):
    carrito_compra= Carrito(request)
    carrito_compra.limpiar()
    return redirect('tienda')    


def generarBoleta(request):
    precio_total=0
    for key, value in request.session['carrito'].items():
        precio_total = precio_total + int(value['precio']) * int(value['cantidad'])
    boleta = Boleta(total = precio_total)
    boleta.save()
    productos = []
    for key, value in request.session['carrito'].items():
            producto = Articulo.objects.get(codigo = value['articulo_id'])
            cant = value['cantidad']
            subtotal = cant * int(value['precio'])
            detalle = detalle_boleta(id_boleta = boleta, id_producto = producto, cantidad = cant, subtotal = subtotal)
            detalle.save()
            productos.append(detalle)
    datos={
        'productos':productos,
        'fecha':boleta.fechaCompra,
        'total': boleta.total
    }
    request.session['boleta'] = boleta.id_boleta
    carrito = Carrito(request)
    carrito.limpiar()
    return render(request, 'alumnos/detallecarrito.html',datos)

@login_required
def perfil(request):
    cliente_id = request.user.id
    boletas = BoletaModel.objects.filter(id_person_id=cliente_id)
    if request.method == 'POST':
        form = UserProfileForm(request.POST, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request,'tu contraseña se ha actualizado correctamente')
            return redirect('perfil')
    else:
            form = UserProfileForm(instance=request.user)
    return render(request, 'alumnos/perfil.html',{'form':form, 'boletas':boletas})
            
def crear_boleta(request):
    if request.method == 'POST':
        form = BoletaForm(request.POST)
        if form.is_valid():
            boleta = form.save(commit=False)
            boleta.id_person = request.user
            boleta.total = boleta.cant * boleta.precio
            boleta.save()
            return redirect('test.html')
    else:
        form = BoletaForm()
    return render(request, 'test.html', {'form': form})



def products_manage(request):
    products = Productos.objects.all()
    page = request.GET.get('page',1)
    queryset = request.GET.get("buscar")
    try:
        paginator = Paginator(products,3)
        products = paginator.page(page)
    except:
        raise Http404
    if queryset:
        products =Productos.objects.filter(
            Q(id = queryset)
        ).distinct()
    print(request.GET)
    ctx  = {'products': products,
            'entity':products,
        'paginator':paginator
            }
    return render(request, 'catalogo/product_manage.html', ctx)


def product_add(request):
    data={
        'form': ProductosForm()
    }
    if request.method == 'POST':
        formulario = ProductosForm(data=request.POST, files=request.FILES)
        if formulario.is_valid():
            formulario.save()
            data["mensaje"] = "Guardado correctamente"
        else:
            data['form'] = formulario 
    return render(request, 'catalogo/product_add.html', data)

def products_edit(request, id):
    producto = get_object_or_404(Productos, id=id)
    data = {
        'form': ProductosForm(instance=producto)
    }
    if request.method == 'POST':
        formulario = ProductosForm(data=request.POST, instance=producto, files=request.FILES)
        if formulario.is_valid():
            formulario.save()
            data["mensaje"] = "Producto modificado correctamente"
            return redirect(to='product_manage')
        data['form'] = formulario
    return render(request, 'catalogo/products_edit.html', data)

def product_delete(request, id):
    product = Productos.objects.get(id=id)
    product.delete()
    return redirect('product_manage')

def home(request):
    return render(request, 'home.html')

def test(request):
    return render(request, 'catalogo/test.html')


def boleta(request):
    cliente_id = request.user.id
    boletas = BoletaModel.objects.filter(id_person_id=cliente_id)

    return render(request, 'alumnos/boleta.html',{'boletas':boletas})


